import pygame
import random
import sys

pygame.init()

# Window setup
WIDTH, HEIGHT = 1000, 715
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("dongle simulator")

# Fonts
font_title = pygame.font.SysFont(None, 72)
font_result = pygame.font.SysFont(None, 64)

# Load images
pcfront = pygame.image.load("pcfront.png")
pcback = pygame.image.load("pcback.png")
pcyes = pygame.image.load("pcyes.png")
pcno = pygame.image.load("pcno.png")

# Load sounds
yay_sound = pygame.mixer.Sound("yay.mp3")
wah_sound = pygame.mixer.Sound("wah.mp3")

# State
current_image = pcfront
result_text = ""
reset_time = None

clock = pygame.time.Clock()

running = True
while running:
    screen.fill((0, 0, 0))

    # Draw current image
    screen.blit(current_image, (0, 0))

    # Draw title
    title_surface = font_title.render("DONGLE SIMULATOR", True, (255, 255, 255))
    title_rect = title_surface.get_rect(center=(WIDTH // 2, 40))
    screen.blit(title_surface, title_rect)

    # Draw result text
    if result_text:
        result_surface = font_result.render(result_text, True, (255, 255, 0))
        result_rect = result_surface.get_rect(center=(WIDTH // 2, HEIGHT - 40))
        screen.blit(result_surface, result_rect)

    pygame.display.flip()

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left click
                if random.random() < 0.2:  # 20% chance
                    current_image = pcyes
                    yay_sound.play()
                    result_text = "WIN"
                    reset_time = pygame.time.get_ticks() + 4000
                else:
                    current_image = pcno
                    wah_sound.play()
                    result_text = "LOSE"
                    reset_time = pygame.time.get_ticks() + 2000

            elif event.button == 3:  # Right click
                if current_image == pcfront:
                    current_image = pcback
                else:
                    current_image = pcfront

    # Reset logic
    if reset_time and pygame.time.get_ticks() >= reset_time:
        current_image = pcfront
        result_text = ""
        reset_time = None

    clock.tick(60)

pygame.quit()
sys.exit()